# app.py placeholder
print("Ready")