import os, psycopg2
from flask import Flask, render_template, request, redirect, url_for, abort
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)
DATABASE_URL = os.getenv("DATABASE_URL")

def db():
    return psycopg2.connect(DATABASE_URL)

@app.route('/')
def accueil():
    return render_template('index.html')

@app.route('/envoi_colis', methods=['GET', 'POST'])
def envoi_colis():
    if request.method == 'POST':
        data = {
            "nom"         : request.form.get('nom', '').strip(),
            "tel"         : request.form.get('telephone', '').strip(),
            "ville_dep"   : request.form.get('ville_depart', '').strip(),
            "ville_arr"   : request.form.get('ville_arrivee', '').strip(),
            "date"        : request.form.get('date_envoi', '').strip(),
            "poids"       : request.form.get('poids', '').strip(),
            "desc"        : request.form.get('description', '').strip(),
            "wa"          : request.form.get('whatsapp', '').strip()
        }
        if not all(data.values()):
            abort(400, "Tous les champs sont obligatoires")

        with db() as conn, conn.cursor() as cur:
            cur.execute("""INSERT INTO colis
                           (nom, tel, ville_dep, ville_arr, date, poids, description, whatsapp)
                           VALUES (%(nom)s,%(tel)s,%(ville_dep)s,%(ville_arr)s,%(date)s,%(poids)s,%(desc)s,%(wa)s)""",
                        data)
        return redirect(url_for('confirmation'))
    return render_template('envoi_colis.html')

@app.route('/inscription_transporteur', methods=['GET', 'POST'])
def inscription_transporteur():
    if request.method == 'POST':
        data = {
            "nom"   : request.form.get('nom', '').strip(),
            "wa"    : request.form.get('whatsapp', '').strip(),
            "date"  : request.form.get('date_disponible', '').strip(),
        }
        if not all(data.values()):
            abort(400, "Tous les champs sont obligatoires")
        with db() as conn, conn.cursor() as cur:
            cur.execute("""INSERT INTO transporteurs (nom, whatsapp, date_disponible)
                           VALUES (%(nom)s,%(wa)s,%(date)s)""", data)
        return redirect(url_for('confirmation'))
    return render_template('inscription_transporteur.html')

@app.route('/confirmation')
def confirmation():
    return render_template('confirmation.html')

@app.route('/webhook/whatsapp', methods=['POST'])
def whatsapp_webhook():
    body = request.values.get('Body', '').lower().strip()
    resp = MessagingResponse(); msg = resp.message()

    if body in ('bonjour', 'salut', 'hello'):
        msg.body("👋 Bienvenue chez *Askely Express* !\n\n"
                 "1️⃣ Envoyer un colis\n"
                 "2️⃣ Devenir transporteur")
    elif body == '1':
        msg.body("📦 Formulaire : https://askelyexpressbon.onrender.com/envoi_colis")
    elif body == '2':
        msg.body("🚚 Formulaire : https://askelyexpressbon.onrender.com/inscription_transporteur")
    else:
        msg.body("❓ Je n’ai pas compris. Envoyez « bonjour ».")
    return str(resp)

if __name__ == '__main__':
    app.run(debug=True)
