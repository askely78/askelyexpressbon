import os
import psycopg2
from flask import Flask, request, render_template
from twilio.twiml.messaging_response import MessagingResponse
import openai

app = Flask(__name__)

# Clés API et DB
openai.api_key = os.environ.get("OPENAI_API_KEY")
DATABASE_URL = os.environ.get("DATABASE_URL")
TWILIO_WHATSAPP_FROM = os.environ.get("TWILIO_WHATSAPP_FROM")

# Connexion DB
conn = psycopg2.connect(DATABASE_URL)
cursor = conn.cursor()

@app.route('/')
def index():
    return render_template("index.html")

@app.route("/webhook/whatsapp", methods=["POST"])
def whatsapp_webhook():
    incoming_msg = request.values.get("Body", "").strip()
    resp = MessagingResponse()
    msg = resp.message()

    try:
        if "bonjour" in incoming_msg.lower():
            msg.body("👋 Bienvenue sur Askely Express ! Posez votre question.")
        else:
            completion = openai.ChatCompletion.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": incoming_msg}]
            )
            response_text = completion.choices[0].message["content"].strip()
            msg.body(response_text)
    except Exception as e:
        msg.body("⚠️ Une erreur est survenue avec l'intelligence artificielle. Veuillez réessayer plus tard.")

    return str(resp)

if __name__ == "__main__":
    app.run(debug=True)