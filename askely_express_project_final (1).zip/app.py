from flask import Flask, request, render_template, redirect, url_for, jsonify
from twilio.twiml.messaging_response import MessagingResponse
import psycopg2
import os

app = Flask(__name__)

# Connexion PostgreSQL
DATABASE_URL = os.getenv("DATABASE_URL")
conn = psycopg2.connect(DATABASE_URL)
cur = conn.cursor()

@app.route('/')
def accueil():
    return "Bienvenue sur Askely Express"

@app.route('/envoi_colis', methods=['GET', 'POST'])
def envoi_colis():
    if request.method == 'POST':
        nom = request.form['nom']
        numero = request.form['numero']
        ville_depart = request.form['ville_depart']
        ville_arrivee = request.form['ville_arrivee']
        date_envoi = request.form['date_envoi']
        poids = request.form['poids']
        cur.execute("INSERT INTO colis (nom, numero, ville_depart, ville_arrivee, date_envoi, poids) VALUES (%s, %s, %s, %s, %s, %s)", (nom, numero, ville_depart, ville_arrivee, date_envoi, poids))
        conn.commit()
        return redirect(url_for('confirmation'))
    return render_template('envoi_colis.html')

@app.route('/inscription_transporteur', methods=['GET', 'POST'])
def inscription_transporteur():
    if request.method == 'POST':
        nom = request.form['nom']
        numero = request.form['numero']
        date_depart = request.form['date_depart']
        cur.execute("INSERT INTO transporteurs (nom, numero, date_depart) VALUES (%s, %s, %s)", (nom, numero, date_depart))
        conn.commit()
        return redirect(url_for('confirmation'))
    return render_template('inscription_transporteur.html')

@app.route('/confirmation')
def confirmation():
    return render_template('confirmation.html')

@app.route('/webhook/whatsapp', methods=['POST'])
def whatsapp_webhook():
    incoming_msg = request.values.get('Body', '').lower()
    resp = MessagingResponse()
    msg = resp.message()

    if "bonjour" in incoming_msg:
        msg.body("👋 Bienvenue chez Askely Express !

1️⃣ Envoyer un colis
2️⃣ Devenir transporteur
3️⃣ Voir les départs disponibles
Répondez par un numéro.")
    elif incoming_msg == "1":
        msg.body("📝 Cliquez pour remplir le formulaire d'envoi : https://askelyexpressbon.onrender.com/envoi_colis")
    elif incoming_msg == "2":
        msg.body("🚚 Cliquez pour devenir transporteur : https://askelyexpressbon.onrender.com/inscription_transporteur")
    else:
        msg.body("❓ Je n’ai pas compris. Veuillez répondre par un chiffre :
1️⃣ Envoyer un colis
2️⃣ Devenir transporteur")

    return str(resp)

if __name__ == '__main__':
    app.run(debug=True)
