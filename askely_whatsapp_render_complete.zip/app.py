
import os, datetime
import psycopg2
from flask import Flask, render_template, request, redirect, url_for
from twilio.twiml.messaging_response import MessagingResponse
from twilio.rest import Client

app = Flask(__name__)

# ---------------- DB & Twilio ---------------- #
DB_URL   = os.getenv("DATABASE_URL")
ACCOUNT  = os.getenv("TWILIO_ACCOUNT_SID")
AUTH     = os.getenv("TWILIO_AUTH_TOKEN")
WH_FROM  = os.getenv("TWILIO_WHATSAPP_FROM")   # format: +14155238886
twilio_client = Client(ACCOUNT, AUTH)

def db():
    return psycopg2.connect(DB_URL)

# ---------------- Web routes ----------------- #
@app.route('/')
def accueil():
    return "Bienvenue sur Askely Express – API en ligne"

# --- Webhook WhatsApp --- #
@app.route('/webhook/whatsapp', methods=['POST'])
def whatsapp_webhook():
    incoming = request.form.get('Body', '').strip().lower()
    resp = MessagingResponse(); msg = resp.message()

    if incoming in {'bonjour', 'salut', 'hello', 'hi'}:
        msg.body(
            "👋 Bonjour et bienvenue chez *Askely Express* !\n"
            "1️⃣ Envoyer un colis\n"
            "2️⃣ Devenir transporteur\n"
            "3️⃣ Suivre un colis (bientôt)\n"
            "4️⃣ Voir les transporteurs disponibles (bientôt)"
        )
    elif incoming == '1':
        msg.body("📦 Formulaire d'envoi : https://{host}/envoi_colis".format(host=request.host))
    elif incoming == '2':
        msg.body("🚚 Inscription transporteur : https://{host}/inscription_transporteur".format(host=request.host))
    else:
        msg.body("❓ Tapez *bonjour* pour afficher le menu.")
    return str(resp)

# --- Formulaire client (colis) --- #
@app.route('/envoi_colis', methods=['GET', 'POST'])
def envoi_colis():
    if request.method == 'POST':
        data = request.form
        date_envoi = data.get('date_envoi')
        con = db(); cur = con.cursor()
        cur.execute('''INSERT INTO colis (nom_client, telephone, ville_depart, ville_arrivee, date_envoi, description)
                       VALUES (%s,%s,%s,%s,%s,%s) RETURNING id''',
                    (data['nom'], data['telephone'], data['ville_depart'], data['ville_arrivee'], date_envoi, data.get('description')))
        colis_id = cur.fetchone()[0]
        # Cherche transporteurs disponibles
        cur.execute("SELECT id, nom, whatsapp FROM transporteurs WHERE date_dispo=%s", (date_envoi,))
        dispo = cur.fetchall()
        con.commit(); cur.close(); con.close()

        # Notifier transporteurs
        for t_id, nom, whatsapp in dispo:
            twilio_client.messages.create(
                from_='whatsapp:' + WH_FROM,
                to='whatsapp:' + whatsapp,
                body=f"🚚 Nouvelle demande de colis pour le {date_envoi}. Répondez OK {colis_id} pour accepter."
            )
        return render_template('confirmation.html', message="✅ Colis enregistré ! Transporteurs notifiés.")
    return render_template('envoi_colis.html')

# --- Formulaire transporteur --- #
@app.route('/inscription_transporteur', methods=['GET', 'POST'])
def inscription_transporteur():
    if request.method == 'POST':
        data = request.form
        con = db(); cur = con.cursor()
        cur.execute('''INSERT INTO transporteurs (nom, ville_depart, ville_arrivee, date_dispo, whatsapp)
                       VALUES (%s,%s,%s,%s,%s)''',
                    (data['nom'], data['ville_depart'], data['ville_arrivee'], data['date_dispo'], data['whatsapp']))
        con.commit(); cur.close(); con.close()
        return render_template('confirmation.html', message="✅ Inscription transporteur réussie !")
    return render_template('inscription_transporteur.html')

@app.route('/confirmation')
def confirmation():
    message = request.args.get('message', "Opération réussie.")
    return render_template('confirmation.html', message=message)

if __name__ == '__main__':
    app.run(debug=True)
