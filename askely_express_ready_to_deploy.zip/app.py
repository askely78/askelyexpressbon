from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
import os
import psycopg2
from datetime import datetime

app = Flask(__name__)

# Connexion à PostgreSQL via DATABASE_URL
DATABASE_URL = os.getenv("DATABASE_URL")

def get_db_connection():
    return psycopg2.connect(DATABASE_URL)

@app.route("/webhook/whatsapp", methods=["POST"])
def whatsapp_webhook():
    incoming_msg = request.values.get("Body", "").strip().lower()
    from_number = request.values.get("From", "")
    resp = MessagingResponse()
    msg = resp.message()

    if incoming_msg in ["hi", "bonjour", "start", "menu"]:
        msg.body("👋 *Bienvenue chez Askely Express !*

📦 Envoyer un colis
🚚 Devenir transporteur
📍 Suivi de colis

Veuillez répondre par :
1️⃣ pour envoyer un colis
2️⃣ pour devenir transporteur
3️⃣ pour suivre un colis")

    elif incoming_msg == "1":
        msg.body("📦 Très bien. Pour envoyer un colis, merci de répondre avec les infos suivantes, chacune sur une ligne :

Nom complet
Ville de départ
Ville d'arrivée
Date souhaitée (format JJ/MM/AAAA)
Numéro WhatsApp
Type de colis
Poids approximatif")

    elif incoming_msg == "2":
        msg.body("🚚 Merci de rejoindre Askely Express ! Veuillez envoyer vos informations sur 6 lignes :

Nom complet
Ville de départ
Ville d'arrivée
Disponibilité (dates)
Numéro WhatsApp
Type de transport (voiture, avion, bus...)")

    elif incoming_msg == "3":
        msg.body("🔍 Pour suivre un colis, entrez l’ID de suivi ou le nom complet de l’expéditeur.")

    elif len(incoming_msg.split("
")) >= 6:
        lignes = incoming_msg.split("
")
        cur = get_db_connection().cursor()
        if len(lignes) == 6 or len(lignes) == 7:
            try:
                nom = lignes[0]
                ville_dep = lignes[1]
                ville_arr = lignes[2]
                date_str = lignes[3]
                numero = lignes[4]
                type_transport = lignes[5]
                extra = lignes[6] if len(lignes) == 7 else ""
                if "transport" in type_transport.lower():
                    # Enregistrement transporteur
                    cur.execute("INSERT INTO transporteurs (nom, ville_depart, ville_arrivee, date_dispo, numero, type_transport) VALUES (%s, %s, %s, %s, %s, %s)",
                                (nom, ville_dep, ville_arr, date_str, numero, type_transport))
                    msg.body("✅ Merci, votre inscription comme transporteur a été enregistrée.")
                else:
                    # Enregistrement colis
                    cur.execute("INSERT INTO colis (nom, ville_depart, ville_arrivee, date_souhaitee, numero, type_colis, poids) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                                (nom, ville_dep, ville_arr, date_str, numero, type_transport, extra))
                    msg.body("📦 Votre demande d’envoi a été reçue. Nous cherchons un transporteur disponible...")
                get_db_connection().commit()
            except Exception as e:
                msg.body("❌ Une erreur est survenue lors de l’enregistrement. Veuillez vérifier les informations envoyées.")
        else:
            msg.body("ℹ️ Veuillez vérifier le format des informations envoyées. Chaque donnée doit être sur une ligne.")

    else:
        msg.body("❓ Je n’ai pas compris votre demande.
Répondez *menu* pour voir les options disponibles.")

    return str(resp)

if __name__ == "__main__":
    app.run(debug=True)